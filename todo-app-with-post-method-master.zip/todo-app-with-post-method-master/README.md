# todo-app-with-post-method
developed a todo app with html post method using express js plus server side validation using express validator
